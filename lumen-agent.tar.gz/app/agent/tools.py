"""
SRE Agent araclari — HEPSI SADECE OKUMA.

Her arac: async def arac(db, **args) -> dict
Sonuclar LLM'e JSON olarak gider; buyuk listeler kirpilir.
Zamanlar LLM'e Istanbul saatiyle ("YYYY-MM-DD HH:MM") verilir.
"""
import base64
import re
from datetime import datetime, timedelta

import httpx
from sqlalchemy import text

from .config import TZ_ANOMALY, TZ_LOCAL, TZ_ZABBIX, entegrasyon, ssl_dogrulama

MAX_SATIR = 50


# --------------------------------------------------------------------------- #
#  Zaman yardimcilari                                                           #
# --------------------------------------------------------------------------- #

def _zaman_al(deger, varsayilan: datetime) -> datetime:
    """LLM'den gelen 'YYYY-MM-DD HH:MM' (Istanbul) veya ISO metnini aware datetime'a cevirir."""
    if not deger:
        return varsayilan
    s = str(deger).strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            d = datetime.strptime(s[:19], fmt)
            return d.replace(tzinfo=TZ_LOCAL)
        except ValueError:
            continue
    try:
        d = datetime.fromisoformat(str(deger))
        return d if d.tzinfo else d.replace(tzinfo=TZ_LOCAL)
    except ValueError:
        return varsayilan


def _db_saati(d: datetime, tz) -> datetime:
    """aware datetime -> kolonun tuttugu dilimde naive datetime."""
    return d.astimezone(tz).replace(tzinfo=None)


def _goster(d, tz) -> str:
    if d is None:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=tz)
    return d.astimezone(TZ_LOCAL).strftime("%Y-%m-%d %H:%M")


def _aralik(args, varsayilan_saat=24):
    simdi = datetime.now(TZ_LOCAL)
    bit = _zaman_al(args.get("bitis"), simdi)
    bas = _zaman_al(args.get("baslangic"), bit - timedelta(hours=varsayilan_saat))
    if bas > bit:
        bas, bit = bit, bas
    if bit - bas > timedelta(days=31):
        bas = bit - timedelta(days=31)
    return bas, bit


def _limit(args, varsayilan=20):
    try:
        return max(1, min(int(args.get("limit") or varsayilan), MAX_SATIR))
    except (TypeError, ValueError):
        return varsayilan


def _kisalt(s, n=400):
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[:n] + "…"


# --------------------------------------------------------------------------- #
#  Zabbix alarmlari                                                             #
# --------------------------------------------------------------------------- #

async def aktif_alarmlar(db, host: str = None, limit: int = None, **_):
    rows = (await db.execute(text("""
        SELECT zabbix_event_id, name, host_name, clock
        FROM zabbix_events
        WHERE resolved_at IS NULL
          AND (CAST(:host AS text) IS NULL OR host_name ILIKE '%' || CAST(:host AS text) || '%')
        ORDER BY clock DESC
        LIMIT :lim
    """), {"host": host or None, "lim": _limit({"limit": limit})})).mappings().all()
    toplam = (await db.execute(text("SELECT count(*) FROM zabbix_events WHERE resolved_at IS NULL"))).scalar()
    return {
        "toplam_aktif_alarm": toplam,
        "filtre_host": host,
        "alarmlar": [{
            "id": r["zabbix_event_id"], "host": r["host_name"], "alarm": r["name"],
            "acilis": _goster(r["clock"], TZ_ZABBIX),
            "sure_dk": int((datetime.now(TZ_LOCAL) - r["clock"].replace(tzinfo=TZ_ZABBIX)).total_seconds() // 60)
                       if r["clock"] else None,
        } for r in rows],
    }


async def alarm_gecmisi(db, host: str = None, baslangic: str = None, bitis: str = None, limit: int = None, **_):
    bas, bit = _aralik({"baslangic": baslangic, "bitis": bitis})
    rows = (await db.execute(text("""
        SELECT zabbix_event_id, name, host_name, clock, resolved_at
        FROM zabbix_events
        WHERE clock >= :bas AND clock < :bit
          AND (CAST(:host AS text) IS NULL OR host_name ILIKE '%' || CAST(:host AS text) || '%')
        ORDER BY clock DESC
        LIMIT :lim
    """), {"bas": _db_saati(bas, TZ_ZABBIX), "bit": _db_saati(bit, TZ_ZABBIX),
           "host": host or None, "lim": _limit({"limit": limit}, 30)})).mappings().all()
    return {
        "aralik": [_goster(bas, TZ_LOCAL), _goster(bit, TZ_LOCAL)],
        "adet": len(rows),
        "alarmlar": [{
            "id": r["zabbix_event_id"], "host": r["host_name"], "alarm": r["name"],
            "acilis": _goster(r["clock"], TZ_ZABBIX),
            "kapanis": _goster(r["resolved_at"], TZ_ZABBIX) if r["resolved_at"] else "açık",
        } for r in rows],
    }


# --------------------------------------------------------------------------- #
#  Anomaliler ve kanallar                                                       #
# --------------------------------------------------------------------------- #

async def anomaliler(db, servis: str = None, kanal: str = None, tip: str = None,
                     baslangic: str = None, bitis: str = None, yanlis_alarmlar_dahil: bool = False,
                     limit: int = None, **_):
    bas, bit = _aralik({"baslangic": baslangic, "bitis": bitis})
    params = {
        "bas": _db_saati(bas, TZ_ANOMALY), "bit": _db_saati(bit, TZ_ANOMALY),
        "servis": servis or None, "kanal": kanal or None, "tip": tip or None,
        "fp": bool(yanlis_alarmlar_dahil), "lim": _limit({"limit": limit}),
    }
    filtre = """
        WHERE a.detected_at >= :bas AND a.detected_at < :bit
          AND (CAST(:servis AS text) IS NULL OR a.service ILIKE '%' || CAST(:servis AS text) || '%')
          AND (CAST(:kanal AS text) IS NULL OR a.channel_code = CAST(:kanal AS text)
               OR c.channel_name ILIKE '%' || CAST(:kanal AS text) || '%')
          AND (CAST(:tip AS text) IS NULL OR a.anomaly_type = CAST(:tip AS text))
          AND (:fp OR NOT COALESCE(a.is_false_positive, false))
    """
    rows = (await db.execute(text(f"""
        SELECT a.id, a.detected_at, a.anomaly_type, a.service, a.channel_code,
               COALESCE(c.channel_name, a.channel_code) AS kanal_adi, a.severity,
               a.score, a.elapsed_mean, a.error_rate, a.tx_count, a.result_code, a.result_desc,
               a.summary, a.acknowledged, a.is_false_positive, a.itsm_ticket_id
        FROM anomaly_events a
        LEFT JOIN channel_mappings c ON c.channel_code = a.channel_code
        {filtre}
        ORDER BY a.detected_at DESC
        LIMIT :lim
    """), params)).mappings().all()
    ozet = (await db.execute(text(f"""
        SELECT a.anomaly_type, count(*) AS adet
        FROM anomaly_events a LEFT JOIN channel_mappings c ON c.channel_code = a.channel_code
        {filtre}
        GROUP BY a.anomaly_type
    """), {k: v for k, v in params.items() if k != "lim"})).mappings().all()
    return {
        "aralik": [_goster(bas, TZ_LOCAL), _goster(bit, TZ_LOCAL)],
        "tip_dagilimi": {r["anomaly_type"]: r["adet"] for r in ozet},
        "gosterilen": len(rows),
        "anomaliler": [{
            "id": r["id"], "zaman": _goster(r["detected_at"], TZ_ANOMALY), "tip": r["anomaly_type"],
            "servis": r["service"], "kanal": r["kanal_adi"], "seviye": r["severity"],
            "skor": r["score"], "sure_ms": r["elapsed_mean"], "hata_orani": r["error_rate"],
            "islem": r["tx_count"], "sonuc_kodu": r["result_code"],
            "ozet": _kisalt(r["summary"], 250),
            "onaylandi": r["acknowledged"], "yanlis_alarm": r["is_false_positive"],
            "itsm": r["itsm_ticket_id"],
        } for r in rows],
    }


async def anomali_detay(db, id: int = None, **_):
    if id is None:
        return {"hata": "id gerekli"}
    r = (await db.execute(text("""
        SELECT a.*, COALESCE(c.channel_name, a.channel_code) AS kanal_adi
        FROM anomaly_events a LEFT JOIN channel_mappings c ON c.channel_code = a.channel_code
        WHERE a.id = :id
    """), {"id": int(id)})).mappings().first()
    if not r:
        return {"hata": f"{id} numarali anomali bulunamadi"}
    d = {k: v for k, v in r.items() if v is not None}
    d["detected_at"] = _goster(r["detected_at"], TZ_ANOMALY)
    for k in ("acknowledged_at", "false_positive_at"):
        if r.get(k):
            d[k] = _goster(r[k], TZ_LOCAL)
    for k in ("summary", "ai_analysis", "result_distribution"):
        if d.get(k):
            d[k] = _kisalt(d[k], 1500)
    return d


async def kanallar(db, **_):
    rows = (await db.execute(text(
        "SELECT channel_code, channel_name, description FROM channel_mappings ORDER BY channel_code"
    ))).mappings().all()
    return {"kanallar": [dict(r) for r in rows]}


# --------------------------------------------------------------------------- #
#  Topoloji (Neo4j)                                                             #
# --------------------------------------------------------------------------- #

async def _neo4j(db, sorgu: str, params: dict):
    b = await entegrasyon(db, "neo4j")
    if not b:
        raise RuntimeError("Neo4j entegrasyonu tanimli degil")
    auth = base64.b64encode(f"neo4j:{b.password}".encode()).decode()
    async with httpx.AsyncClient(verify=ssl_dogrulama(), timeout=15) as c:
        r = await c.post(f"{b.url}/db/{b.database}/tx/commit",
                         headers={"Authorization": f"Basic {auth}", "Content-Type": "application/json"},
                         json={"statements": [{"statement": sorgu, "parameters": params}]})
        r.raise_for_status()
        data = r.json()
    if data.get("errors"):
        raise RuntimeError(data["errors"][0].get("message", "Neo4j hatasi"))
    res = data["results"][0]
    return [dict(zip(res["columns"], row["row"])) for row in res["data"]]


async def topoloji(db, ad: str = None, derinlik: int = 1, **_):
    if not ad:
        return {"hata": "ad gerekli (host veya servis adi)"}
    d = max(1, min(int(derinlik or 1), 3))
    bulunan = await _neo4j(db, """
        MATCH (n) WHERE n.name IS NOT NULL AND toLower(n.name) = toLower($ad)
        RETURN n.name AS ad, labels(n) AS tip LIMIT 1
    """, {"ad": ad})
    if not bulunan:
        aday = await _neo4j(db, """
            MATCH (n) WHERE n.name IS NOT NULL AND toLower(n.name) CONTAINS toLower($ad)
            RETURN n.name AS ad, labels(n) AS tip LIMIT 10
        """, {"ad": ad})
        return {"hata": f"'{ad}' topolojide birebir bulunamadi", "benzer_adlar": aday}

    iliskiler = await _neo4j(db, f"""
        MATCH (n) WHERE toLower(n.name) = toLower($ad)
        MATCH p = (n)-[rels*1..{d}]-(m)
        WHERE all(r IN rels WHERE type(r) <> 'HAS_ALARM')
        UNWIND relationships(p) AS r
        WITH DISTINCT r
        RETURN startNode(r).name AS kaynak, labels(startNode(r))[0] AS kaynak_tip,
               type(r) AS iliski,
               endNode(r).name AS hedef, labels(endNode(r))[0] AS hedef_tip
        LIMIT 150
    """, {"ad": ad})

    adlar = {ad} | {x["kaynak"] for x in iliskiler} | {x["hedef"] for x in iliskiler}
    alarmlar = await _neo4j(db, """
        MATCH (h)-[:HAS_ALARM]->(a:ZabbixEvent)
        WHERE a.aktif = true AND h.name IN $adlar
        RETURN h.name AS host, a.event_id AS alarm_id, a.name AS alarm, a.clock AS zaman
        LIMIT 50
    """, {"adlar": list(adlar)})

    return {
        "merkez": bulunan[0],
        "derinlik": d,
        "iliski_sayisi": len(iliskiler),
        "iliskiler": iliskiler,
        "aktif_alarmli_dugumler": alarmlar,
        "not": "İlişki yönü kaynak -> hedef. Aktif alarmlar topolojideki ZabbixEvent düğümlerinden.",
    }


# --------------------------------------------------------------------------- #
#  Benzer gecmis olaylar (pgvector)                                             #
# --------------------------------------------------------------------------- #

SORGU_TALIMATI = "Verilen olay açıklamasına benzeyen geçmiş anomalileri ve çözümlerini bul"


async def _sorgu_embedding(db, metin: str):
    b = await entegrasyon(db, "embedding")
    if not b or not b.api_key:
        raise RuntimeError("Embedding entegrasyonu tanimli degil")
    async with httpx.AsyncClient(verify=ssl_dogrulama(), timeout=60) as c:
        r = await c.post(f"{b.url}/embeddings",
                         headers={"Authorization": f"Bearer {b.api_key}"},
                         json={"model": b.model or "llama-embed-nemotron-8b",
                               "input": [f"Instruct: {SORGU_TALIMATI}\nQuery: {metin}"]})
        r.raise_for_status()
        v = r.json()["data"][0]["embedding"]
    return "[" + ",".join(f"{x:.7g}" for x in v) + "]"


async def benzer_olaylar(db, metin: str = None, servis: str = None, sadece_yanlis_alarm_olmayanlar: bool = False,
                         limit: int = None, **_):
    if not metin:
        return {"hata": "metin gerekli"}
    vec = await _sorgu_embedding(db, metin)
    rows = (await db.execute(text("""
        SELECT source_id, content, metadata, 1 - (embedding <=> CAST(:v AS vector)) AS benzerlik
        FROM knowledge_embeddings
        WHERE source_type = 'anomaly'
          AND (CAST(:servis AS text) IS NULL OR metadata->>'service' ILIKE '%' || CAST(:servis AS text) || '%')
          AND (NOT :fp OR COALESCE((metadata->>'is_false_positive')::boolean, false) = false)
        ORDER BY embedding <=> CAST(:v AS vector)
        LIMIT :lim
    """), {"v": vec, "servis": servis or None, "fp": bool(sadece_yanlis_alarm_olmayanlar),
           "lim": _limit({"limit": limit}, 5)})).mappings().all()
    return {
        "sonuclar": [{
            "anomali_id": r["source_id"],
            "benzerlik": round(float(r["benzerlik"]), 3),
            "servis": (r["metadata"] or {}).get("service"),
            "kanal": (r["metadata"] or {}).get("channel_name"),
            "yanlis_alarm": (r["metadata"] or {}).get("is_false_positive"),
            "metin": _kisalt(r["content"], 600),
        } for r in rows],
        "not": "Benzerlik 0-1 arası; 0.8 üstü güçlü benzerlik. Kesin sayılar için anomaliler aracını kullan.",
    }


# --------------------------------------------------------------------------- #
#  Kayit                                                                        #
# --------------------------------------------------------------------------- #

ARACLAR = {
    "aktif_alarmlar": aktif_alarmlar,
    "alarm_gecmisi": alarm_gecmisi,
    "anomaliler": anomaliler,
    "anomali_detay": anomali_detay,
    "kanallar": kanallar,
    "topoloji": topoloji,
    "benzer_olaylar": benzer_olaylar,
}

_ZAMAN = {"type": "string", "description": "İstanbul saati, 'YYYY-MM-DD HH:MM'"}

ARAC_TANIMLARI = [
    {"type": "function", "function": {
        "name": "aktif_alarmlar",
        "description": "Şu an açık olan Zabbix DISASTER alarmlarını getirir. Toplam sayı ve en yeni alarmlar.",
        "parameters": {"type": "object", "properties": {
            "host": {"type": "string", "description": "Host adı veya bir kısmı (opsiyonel)"},
            "limit": {"type": "integer"}}}}},
    {"type": "function", "function": {
        "name": "alarm_gecmisi",
        "description": "Belirli zaman aralığında açılmış Zabbix alarmları (açık ve kapanmış). Varsayılan son 24 saat.",
        "parameters": {"type": "object", "properties": {
            "host": {"type": "string"}, "baslangic": _ZAMAN, "bitis": _ZAMAN, "limit": {"type": "integer"}}}}},
    {"type": "function", "function": {
        "name": "anomaliler",
        "description": ("Anomali kayıtlarını servis, kanal, tip ve zaman aralığına göre getirir. "
                        "Varsayılan son 24 saat, yanlış alarmlar hariç. Tip dağılımı da döner."),
        "parameters": {"type": "object", "properties": {
            "servis": {"type": "string", "description": "Servis adı veya bir kısmı"},
            "kanal": {"type": "string", "description": "Kanal kodu (ör. 102) veya kanal adı"},
            "tip": {"type": "string", "enum": ["ml_rt", "zscore", "rule"]},
            "baslangic": _ZAMAN, "bitis": _ZAMAN,
            "yanlis_alarmlar_dahil": {"type": "boolean"},
            "limit": {"type": "integer"}}}}},
    {"type": "function", "function": {
        "name": "anomali_detay",
        "description": "Tek bir anomalinin tüm alanları (özet, AI analizi, sonuç dağılımı, onay ve yanlış alarm bilgisi).",
        "parameters": {"type": "object", "properties": {"id": {"type": "integer"}}, "required": ["id"]}}},
    {"type": "function", "function": {
        "name": "kanallar",
        "description": "Kanal kodları ve adları listesi (ör. 102 = Bireysel Mobil Bankacılık).",
        "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {
        "name": "topoloji",
        "description": ("Neo4j servis topolojisinde bir host veya servisin komşularını ve aralarındaki ilişkileri, "
                        "ayrıca bu düğümlerdeki aktif alarmları getirir. Etki ve kök neden analizi için kullan."),
        "parameters": {"type": "object", "properties": {
            "ad": {"type": "string", "description": "Host veya servis adı (tam ad)"},
            "derinlik": {"type": "integer", "description": "1-3, varsayılan 1"}}, "required": ["ad"]}}},
    {"type": "function", "function": {
        "name": "benzer_olaylar",
        "description": ("Verilen açıklamaya anlamca benzeyen geçmiş anomalileri bulur (vektör araması). "
                        "'Bu daha önce oldu mu, nasıl sonuçlandı, yanlış alarm mıydı?' soruları için."),
        "parameters": {"type": "object", "properties": {
            "metin": {"type": "string", "description": "Olayın kısa açıklaması"},
            "servis": {"type": "string"},
            "sadece_yanlis_alarm_olmayanlar": {"type": "boolean"},
            "limit": {"type": "integer"}}, "required": ["metin"]}}},
]
