"""
SRE Agent dongusu.

Akis: soru -> LLM (araclarla) -> arac cagrilari -> sonuclar LLM'e -> ... -> nihai cevap
Her calistirma agent_runs'a, her arac cagrisi agent_steps'e yazilir.

Hizli test (yetki kontrolu olmadan, container icinden):
  docker exec -it lumen-app python3 -m app.agent.core "Su an hangi alarmlar acik?"
"""
import asyncio
import json
import logging
import os
import time
from datetime import datetime

import httpx
from sqlalchemy import text

from .config import TZ_LOCAL, llm_baglantisi, ssl_dogrulama
from .tools import ARAC_TANIMLARI, ARACLAR

logger = logging.getLogger(__name__)

MAX_ADIM = int(os.environ.get("AGENT_MAX_STEPS", "8"))
ARAC_SONUC_MAX = 12000          # LLM'e giden tek arac sonucunun karakter siniri
LLM_TIMEOUT = 120

SISTEM_PROMPT = """Sen Lumen'in SRE asistanısın. Bir bankanın NOC ve SRE ekiplerine Türkçe yardım ediyorsun.
Şu an: {simdi} (İstanbul saati).

KURALLAR
1. Sadece araçlardan gelen veriye dayanarak konuş. Veri yoksa ya da yetersizse "bu veriyle bilemiyorum" de; tahmin yürütüyorsan bunu açıkça "muhtemelen" diye belirt.
2. Her somut iddianın yanına kaynağını yaz: alarm ID, anomali ID, zaman, topoloji ilişkisi. Örnek: "(anomali #11448, 07:28)".
3. Sayı soran sorularda (kaç alarm, kaç anomali) anomaliler / aktif_alarmlar araçlarının döndürdüğü sayıları kullan; benzer_olaylar sonuçlarını sayım için kullanma.
4. Zamanları İstanbul saatiyle "YYYY-MM-DD HH:MM" biçiminde ver. Kullanıcı "dün", "son 2 saat" derse bunu şu anki zamana göre hesapla.
5. Sen sadece okuyabilirsin. Restart, kapatma, ticket açma gibi işlemleri yapamazsın; gerekiyorsa operatöre öneri olarak yaz.
6. Yanlış alarm olarak işaretlenmiş geçmiş olayları ayrıca belirt; bunlar güçlü bir ipucudur.
7. Gereksiz araç çağırma. Cevap için yeterli veri toplandığında dur.

OLAY ANALİZİ İSTENDİĞİNDE CEVAP BİÇİMİ
**Özet:** 1-2 cümle.
**Muhtemel neden:** kanıtlarıyla.
**Etki:** etkilenen servis/kanal/host.
**Kanıtlar:** madde madde, kaynaklı.
**Benzer geçmiş olaylar:** varsa.
**Önerilen adımlar:** operatörün yapabileceği somut adımlar.
**Belirsizlikler:** emin olmadığın noktalar.

Basit sorulara kısa ve doğrudan cevap ver, bu biçimi kullanma."""


# --------------------------------------------------------------------------- #
#  Kayit                                                                        #
# --------------------------------------------------------------------------- #

async def _run_baslat(db, kullanici, soru, baglam, model):
    rid = (await db.execute(text("""
        INSERT INTO agent_runs (user_name, question, context, model)
        VALUES (:u, :q, CAST(:c AS jsonb), :m) RETURNING id
    """), {"u": kullanici, "q": soru, "c": json.dumps(baglam or {}, ensure_ascii=False), "m": model})).scalar()
    await db.commit()
    return rid


async def _adim_kaydet(db, run_id, no, arac, args, sonuc, gerekce, sure_ms, hata):
    await db.execute(text("""
        INSERT INTO agent_steps (run_id, step_no, tool_name, arguments, result, reasoning, duration_ms, error)
        VALUES (:r, :n, :t, CAST(:a AS jsonb), CAST(:s AS jsonb), :g, :d, :e)
    """), {"r": run_id, "n": no, "t": arac, "a": json.dumps(args, ensure_ascii=False, default=str),
           "s": json.dumps(sonuc, ensure_ascii=False, default=str) if sonuc is not None else None,
           "g": gerekce, "d": sure_ms, "e": hata})
    await db.commit()


async def _run_bitir(db, run_id, cevap, durum, hata, pt, ct):
    await db.execute(text("""
        UPDATE agent_runs SET answer = :a, status = :s, error = :e,
               prompt_tokens = :pt, completion_tokens = :ct, finished_at = now()
        WHERE id = :id
    """), {"a": cevap, "s": durum, "e": hata, "pt": pt, "ct": ct, "id": run_id})
    await db.commit()


# --------------------------------------------------------------------------- #
#  Yetki                                                                        #
# --------------------------------------------------------------------------- #

def arac_izinli(kullanici_rolleri, arac_adi: str) -> bool:
    """RBAC baglantisi icin kanca. Simdilik tum okuma araclari herkese acik.
    Ornek: topoloji'yi sadece 'noc' ve 'sre' rollerine acmak icin burayi duzenleyin."""
    return True


# --------------------------------------------------------------------------- #
#  Dongu                                                                        #
# --------------------------------------------------------------------------- #

async def _llm(client, b, mesajlar):
    r = await client.post(
        f"{b.url}/chat/completions",
        headers={"Authorization": f"Bearer {b.api_key}", "Content-Type": "application/json"},
        json={"model": b.model, "messages": mesajlar, "tools": ARAC_TANIMLARI,
              "tool_choice": "auto", "temperature": 0.1},
    )
    if r.status_code != 200:
        raise RuntimeError(f"LLM HTTP {r.status_code}: {r.text[:300]}")
    return r.json()


async def agent_calistir(db, soru: str, kullanici: str, baglam: dict = None, roller=None) -> dict:
    b = await llm_baglantisi(db)
    run_id = await _run_baslat(db, kullanici, soru, baglam, b.model)

    simdi = datetime.now(TZ_LOCAL).strftime("%Y-%m-%d %H:%M (%A)")
    kullanici_mesaji = soru if not baglam else f"{soru}\n\nBağlam:\n{json.dumps(baglam, ensure_ascii=False, default=str)}"
    mesajlar = [
        {"role": "system", "content": SISTEM_PROMPT.format(simdi=simdi)},
        {"role": "user", "content": kullanici_mesaji},
    ]
    adimlar, pt, ct, no = [], 0, 0, 0

    try:
        async with httpx.AsyncClient(verify=ssl_dogrulama(), timeout=LLM_TIMEOUT) as client:
            for _ in range(MAX_ADIM):
                cevap = await _llm(client, b, mesajlar)
                kul = cevap.get("usage") or {}
                pt += kul.get("prompt_tokens", 0)
                ct += kul.get("completion_tokens", 0)
                msg = cevap["choices"][0]["message"]
                gerekce = msg.get("reasoning_content") or (msg.get("provider_specific_fields") or {}).get("reasoning")
                tool_calls = msg.get("tool_calls") or []

                if not tool_calls:
                    son = (msg.get("content") or "").strip() or "Cevap üretilemedi."
                    await _run_bitir(db, run_id, son, "done", None, pt, ct)
                    return {"run_id": run_id, "cevap": son, "adimlar": adimlar, "durum": "done"}

                # reasoning alanlarini geri gondermiyoruz
                mesajlar.append({"role": "assistant", "content": msg.get("content"), "tool_calls": tool_calls})

                for tc in tool_calls:
                    no += 1
                    ad = tc["function"]["name"]
                    try:
                        args = json.loads(tc["function"].get("arguments") or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    bas = time.monotonic()
                    sonuc, hata = None, None
                    if ad not in ARACLAR:
                        hata = f"Bilinmeyen araç: {ad}"
                    elif not arac_izinli(roller, ad):
                        hata = f"Bu aracı kullanma yetkiniz yok: {ad}"
                    else:
                        try:
                            sonuc = await ARACLAR[ad](db, **args)
                        except Exception as e:
                            await db.rollback()
                            hata = f"{type(e).__name__}: {e}"
                            logger.warning(f"Agent araç hatası {ad}: {hata}")
                    sure = int((time.monotonic() - bas) * 1000)
                    await _adim_kaydet(db, run_id, no, ad, args, sonuc, gerekce, sure, hata)
                    adimlar.append({"no": no, "arac": ad, "parametreler": args, "sure_ms": sure, "hata": hata})
                    gerekce = None   # ayni gerekceyi her adima yazma

                    icerik = json.dumps(sonuc if hata is None else {"hata": hata},
                                        ensure_ascii=False, default=str)
                    if len(icerik) > ARAC_SONUC_MAX:
                        icerik = icerik[:ARAC_SONUC_MAX] + ' …"(kırpıldı)"'
                    mesajlar.append({"role": "tool", "tool_call_id": tc["id"], "content": icerik})

            # adim siniri: son bir kez araçsız özet iste
            mesajlar.append({"role": "user", "content":
                             "Adım sınırına ulaştın. Şu ana kadar toplanan veriye göre cevabını yaz; eksik kalanları belirt."})
            r = await client.post(f"{b.url}/chat/completions",
                                  headers={"Authorization": f"Bearer {b.api_key}"},
                                  json={"model": b.model, "messages": mesajlar, "temperature": 0.1})
            son = (r.json()["choices"][0]["message"].get("content") or "").strip() if r.status_code == 200 else \
                "Adım sınırına ulaşıldı."
            await _run_bitir(db, run_id, son, "step_limit", None, pt, ct)
            return {"run_id": run_id, "cevap": son, "adimlar": adimlar, "durum": "step_limit"}

    except Exception as e:
        logger.exception("Agent hatası")
        await db.rollback()
        await _run_bitir(db, run_id, None, "error", f"{type(e).__name__}: {e}", pt, ct)
        return {"run_id": run_id, "cevap": None, "adimlar": adimlar, "durum": "error",
                "hata": "Agent çalışırken bir hata oluştu. Ayrıntı agent_runs kaydında."}


# --------------------------------------------------------------------------- #
#  Komut satiri testi                                                           #
# --------------------------------------------------------------------------- #

async def _cli(soru):
    from app.database import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        s = await agent_calistir(db, soru, kullanici="cli-test")
    for a in s["adimlar"]:
        print(f"  [{a['no']}] {a['arac']}({json.dumps(a['parametreler'], ensure_ascii=False)}) "
              f"{a['sure_ms']}ms {'HATA: ' + a['hata'] if a['hata'] else ''}")
    print(f"\nrun_id={s['run_id']} durum={s['durum']}\n")
    print(s["cevap"] or s.get("hata"))


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.WARNING)
    asyncio.run(_cli(" ".join(sys.argv[1:]) or "Şu an açık alarmlar neler?"))
