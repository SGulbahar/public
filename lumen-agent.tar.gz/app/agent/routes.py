"""
SRE Agent API

POST /api/v1/agent/ask                  {soru, baglam?}  -> {run_id, cevap, adimlar, durum}
GET  /api/v1/agent/runs/{run_id}        calistirma + adimlar
POST /api/v1/agent/runs/{run_id}/feedback {faydali: bool, not?}

main.py:
    from app.agent.routes import router as agent_router
    app.include_router(agent_router)
"""
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.database import AsyncSessionLocal

# DIKKAT: Lumen'deki mevcut kullanici dogrulama bagimliligini buraya baglayin.
# Bulmak icin: grep -rn "def get_current_user\|Depends(get_current" /app/app | head
# Import bulunamazsa endpoint'ler ACIK KALMAZ: her istek 503 doner.
try:
    from app.api.deps import get_current_user  # <-- kendi yolunuzla degistirin
except ImportError:  # pragma: no cover
    import logging as _l
    _l.getLogger(__name__).error("Agent: get_current_user import edilemedi, agent endpoint'leri kapali")

    async def get_current_user():
        raise HTTPException(503, "Agent kimlik doğrulaması yapılandırılmamış")

from .core import agent_calistir

router = APIRouter(prefix="/api/v1/agent", tags=["agent"])


async def get_db():
    async with AsyncSessionLocal() as db:
        yield db


def _ad(user) -> str:
    for alan in ("username", "full_name", "name", "email", "sub"):
        v = getattr(user, alan, None) if not isinstance(user, dict) else user.get(alan)
        if v:
            return str(v)
    return "bilinmiyor"


def _roller(user):
    v = getattr(user, "roles", None) if not isinstance(user, dict) else user.get("roles")
    return v or []


class SoruIstegi(BaseModel):
    soru: str = Field(..., min_length=2, max_length=2000)
    baglam: Optional[dict[str, Any]] = None   # ör. {"anomali_id": 11448} veya {"alarm_id": "..."}


class GeriBildirim(BaseModel):
    faydali: bool
    not_: Optional[str] = Field(None, alias="not", max_length=1000)


@router.post("/ask")
async def ask(req: SoruIstegi, user=Depends(get_current_user), db=Depends(get_db)):
    return await agent_calistir(db, req.soru, kullanici=_ad(user), baglam=req.baglam, roller=_roller(user))


@router.get("/runs/{run_id}")
async def run_detay(run_id: int, user=Depends(get_current_user), db=Depends(get_db)):
    run = (await db.execute(text("SELECT * FROM agent_runs WHERE id = :id"), {"id": run_id})).mappings().first()
    if not run:
        raise HTTPException(404, "Kayıt bulunamadı")
    steps = (await db.execute(text("""
        SELECT step_no, tool_name, arguments, duration_ms, error, created_at
        FROM agent_steps WHERE run_id = :id ORDER BY step_no
    """), {"id": run_id})).mappings().all()
    return {"run": dict(run), "adimlar": [dict(s) for s in steps]}


@router.post("/runs/{run_id}/feedback")
async def feedback(run_id: int, req: GeriBildirim, user=Depends(get_current_user), db=Depends(get_db)):
    r = await db.execute(text("""
        UPDATE agent_runs SET feedback = :f, feedback_note = :n, feedback_by = :u, feedback_at = now()
        WHERE id = :id
    """), {"f": "faydali" if req.faydali else "yanlis", "n": req.not_, "u": _ad(user), "id": run_id})
    await db.commit()
    if r.rowcount == 0:
        raise HTTPException(404, "Kayıt bulunamadı")
    return {"ok": True}
