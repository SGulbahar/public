"""
Agent icin baglanti ayarlari: integrations tablosundan (Fernet ile sifreli), yoksa ortam degiskenlerinden.

integrations kayitlari:
  key='llm'        config: {"url": "https://litellm.../v1", "model": "openai/gpt-oss-120b"}  secrets: {"api_key": ...}
  key='embedding'  config: {"url": ..., "model": "llama-embed-nemotron-8b"}               secrets: {"api_key": ...}
  key='neo4j'      config: {"url": ..., "database": "neo4j"}                             secrets: {"password": ...}

Ortam degiskeni yedekleri: AGENT_LLM_URL, AGENT_LLM_MODEL, AGENT_LLM_API_KEY
Ic CA: EMBED_CA_FILE veya SSL_CERT_FILE
Zaman dilimleri:
  ZABBIX_TZ  (varsayilan UTC)            -> zabbix_events.clock hangi saatte tutuluyor
  ANOMALY_TZ (varsayilan Europe/Istanbul) -> anomaly_events.detected_at hangi saatte tutuluyor
"""
import json
import os
import ssl
from dataclasses import dataclass
from typing import Optional
from zoneinfo import ZoneInfo

from sqlalchemy import text

TZ_LOCAL = ZoneInfo("Europe/Istanbul")
TZ_ZABBIX = ZoneInfo(os.environ.get("ZABBIX_TZ", "UTC"))
TZ_ANOMALY = ZoneInfo(os.environ.get("ANOMALY_TZ", "Europe/Istanbul"))


@dataclass
class Baglanti:
    url: str
    model: str = ""
    api_key: str = ""
    database: str = ""
    password: str = ""


def ssl_dogrulama():
    """httpx 'verify' parametresi icin: CA dosyasi varsa SSLContext, yoksa True."""
    ca = os.environ.get("EMBED_CA_FILE") or os.environ.get("SSL_CERT_FILE")
    if ca and os.path.exists(ca):
        ctx = ssl.create_default_context()
        ctx.load_verify_locations(cafile=ca)
        return ctx
    return True


def _coz(deger: str) -> str:
    sk = os.environ.get("LUMEN_SECRET_KEY", "")
    if not deger or not sk:
        return deger or ""
    try:
        from cryptography.fernet import Fernet
        return Fernet(sk.encode()).decrypt(deger.encode()).decode()
    except Exception:
        return deger


async def entegrasyon(db, key: str) -> Optional[Baglanti]:
    row = (await db.execute(
        text("SELECT config, secrets, enabled FROM integrations WHERE key = :k"), {"k": key}
    )).mappings().first()
    if not row or not row["enabled"]:
        return None
    cfg = row["config"] if isinstance(row["config"], dict) else json.loads(row["config"] or "{}")
    sec = row["secrets"] if isinstance(row["secrets"], dict) else json.loads(row["secrets"] or "{}")
    url = (cfg.get("url") or "").rstrip("/")
    if not url:
        return None
    return Baglanti(
        url=url,
        model=cfg.get("model", ""),
        api_key=_coz(sec.get("api_key", "")),
        database=cfg.get("database", "neo4j"),
        password=_coz(sec.get("password", "")),
    )


async def llm_baglantisi(db) -> Baglanti:
    b = await entegrasyon(db, "llm")
    if b and b.api_key:
        b.model = b.model or "openai/gpt-oss-120b"
        return b
    url = os.environ.get("AGENT_LLM_URL", "").rstrip("/")
    key = os.environ.get("AGENT_LLM_API_KEY", "")
    if not url or not key:
        raise RuntimeError("LLM ayari yok: integrations'a key='llm' kaydi ekleyin "
                           "veya AGENT_LLM_URL / AGENT_LLM_API_KEY tanimlayin.")
    return Baglanti(url=url, model=os.environ.get("AGENT_LLM_MODEL", "openai/gpt-oss-120b"), api_key=key)
